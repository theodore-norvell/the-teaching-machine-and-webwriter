/* The interface for class Complex */
class Complex {
public:
	double getReal();
	double getImag();
	// ...
};
