#include <iostream>
using namespace std;

int main(){
    cout << 4*3+7;
    cout << '\n';
    cout << 4+3*7;
    cout << '\n';
    cout << (4+3)*7;       
	return 0; 
}
