// JavaScript Document
/******************************************************************************
 JavaScript code by
   	Michael Bruce-Lockhart
	Copyright 2001, 2004, 2006
	All rights reserved. May not be used, copied, distributed or reverse engineered
	without the permission of the author.
***********************************************************************************/


if (!nestingDepth) var nestingDepth = "";

writeHeader();

function writeHeader(){
	document.write('<meta NAME="Author" CONTENT="', authors, '">');
	document.write('<meta NAME="Generator" CONTENT="', generator, '">');
	document.write('<meta NAME="copyright" CONTENT="', copyright, '">');
	document.write('<meta NAME="resource-type" CONTENT="document">');
	document.write('<meta NAME="distribution" CONTENT="global">');
	document.write('<link rel="stylesheet" type="text/css" media="screen" href="');
		document.write(nestingDepth, styleFolder, 'navBar.css" title="webWriter navigation bar stylesheet">');
	document.write('<link rel="stylesheet" type="text/css" media="print" href="');
		document.write(nestingDepth, styleFolder, 'navBarprint.css" title="webWriter navigation bar Print stylesheet">');
}


