class A {
	int i,j;
protected:
	int k;
public
	int george();
}

class B: public A {
	int l;
public
	int m;
	int john();
}

class C: private A {
	int n;
public:
	int alice();
}    