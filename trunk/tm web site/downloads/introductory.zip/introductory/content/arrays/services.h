void loadFromFile(float theArray[], int& size);

void sort(float theArray[], int n);

void swap(float& arg1, float& arg2);
