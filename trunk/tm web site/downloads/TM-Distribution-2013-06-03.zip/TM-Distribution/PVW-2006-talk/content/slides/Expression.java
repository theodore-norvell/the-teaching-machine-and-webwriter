class Expression {

    public static void main() {
        int i = 9 ;
        int j = 8 ;
        float f = (i + j) / 2 ;
        System.out.println( f ) ;
        return ;
    }
}