#include <iostream>
using namespace std;

int main(){
// variable declarations: have the effect of setting space aside for... 
    int i = 44;
    long j = 98765432199;
    int k;
    double y;
    float x = 7.3;
    char character = 'N';
        
    character = 'n';
    k = j;
    y = i;
    x = 2*y; 
    y = 1.60217646e-19;
        
    return 0;
}
        
