// JavaScript Document
// Assumes tocNavigator.js loaded

var root = new Node("content/titlePage.htm");

// Site Navigation map
// define the directories for convenience
var intro = "content/introduction/";
var expression = "content/expression/";
var passByRef = "content/passByRef/";
var copyCons = "content/copyConstructors/";
var linked = "content/linkedList/";
var sorting = "content/sort/";
var javaObjects = "content/javaObjects/";
var siteTitle = "Interactive Embedded Examples";


var treeWalker = new Walker(root);

// Now define the navigation map
root.addChild(new Node(intro + "introduction.htm"));
root.addChild(new Node(expression + "expression.htm"));
root.addChild(new Node(passByRef + "passByReference.htm"));
root.addChild(new Node(copyCons + "copycons.htm"));
root.addChild(new Node(linked + "linkedList.htm"));
root.addChild(new Node(sorting + "sorting.htm"));
root.addChild(new Node(javaObjects + "objects.htm"));







