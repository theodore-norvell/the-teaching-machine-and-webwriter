int f1(){
	Complex x,y;
	double z;
	z = ::x.getReal();
	//...
}

