class Node {
    public int value ;
    
    public Node next ;
    
    public Node() { value = 0 ; next = null ; }
    
    public Node( int value, Node next ) {
        this.value = value ;
        this.next = next ;
    }
}

public class BuildListExample {
    public static void main( String[] args ) {
        Node head ;
        head = new Node() ;
        head = new Node( 2, null ) ;
        head = new Node( 1, head ) ;
        head = new Node( 0, head ) ;
    
        Node p = head ;
        Node q = null ;
        while( p != null ) {
            q = new Node( p.value, q ) ;
            p = p.next ;
        }
        return ;
    }
}