/*#HA*/class Node {
    public: int value ;
    
    public: Node *next ;
    
    public: Node( int value, Node *next ) {
        this->value = value ;
        this->next = next ;
    }
} ;

int main( ) {
    Node *head ;
    head = new Node( 2, 0 ) ;
    head = new Node( 1, head ) ;
    head = new Node( 0, head ) ;
/*#DA*/
    // Copy a list
    Node *p = head ;
    Node *copyHead = 0 ;
    Node **q = & copyHead ;
    // @invariant: ...
    while( p != 0 ) {
        *q = new Node( p->value, 0 ) ;
        p = p->next ;
        q = & (*q)->next ;
    }
/*#HA*/
    return 0 ;
}
