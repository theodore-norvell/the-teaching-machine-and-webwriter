Since I don't know which OS you have, you are largely on your own.
The following makes sense for UNIX and presumably Mac.

First read the licence file: LICENCE

Do you agree with the terms?  Ok. Proceed.

First off you'll need a Java Run-time Environment.

Untar the distribution file.

Copy the initial.tmcfg file to your home directory.

The following command should start the TM up.
    java -cp installDir/tm.jar tm.TMMainFrame -id installDir -ic ~/initial.tmcfg
("installDir" should be replaced by the path to the installation
directory, i.e. the directory containing tm.jar.

You can also add the path of a file as an argument, so that the
TM will load that file to start with.
   java -cp installDir/tm.jar tm.TMMainFrame -id installDir  -ic ~/initial.tmcfg quadratic2.cpp


----------

Do you use Eclipse?  If so read the file Eclipse-plug-in-instructions.txt
to see how easy it is to install the TM as a plug-in for Eclipse.