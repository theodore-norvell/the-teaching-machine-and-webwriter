MAC OS X installation of the teaching machine.

First read the licence file: LICENCE

Do you agree with the terms?  Ok. Proceed.

You need a Java Runtime Environment. Mac OS X comes with a JRE installed.

Drag the TeachingMachine application from this folder to your Applications folder. You may then attach it to your Dock.

----------

Do you use Eclipse?  If so read the file Eclipse-plug-in-instructions.txt
to see how easy it is to install the TM as a plug-in for Eclipse.