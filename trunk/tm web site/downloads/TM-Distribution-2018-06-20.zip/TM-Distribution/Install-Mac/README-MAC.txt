MAC OS X installation of the teaching machine.

First read the licence file: LICENCE

Do you agree with the terms?  Ok. Proceed.

You need a Java Runtime Environment. Mac OS X comes with a JRE installed.

Drag the TeachingMachine application from this folder to your Applications folder.

The first time you use the TeachingMachine application you will likely be told that it can not be opened because it is from an unidentified developer. In that case simply click on OK.  Then open System Preferences >> Security and Privacy.  On the general tab look for a button that says "Open Anyway". Click on that.

----------

Do you use Eclipse?  If so read the file Eclipse-plug-in-instructions.txt
to see how easy it is to install the TM as a plug-in for Eclipse.
