class Complex {
	double re,im;
public:
	double getReal(); // accessors
	double getImag();
	void set(double r, double i); // mutator
};