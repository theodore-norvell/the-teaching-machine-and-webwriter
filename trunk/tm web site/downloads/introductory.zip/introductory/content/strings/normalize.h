#include <string>
using namespace std;


void normalize(string& name);
void eatSpacesAt(string& str, int position);
