int  /*#B="x1Vis"*/ /*#b="x1Vis"*/x1/*#/b*/, /*#B="aVis"*/ /*#b="aVis"*/a[10]/*#/b*/;
int main() {
	int /*#B="i1Vis"*/ /*#b="i1Vis"*/i/*#/b*/, /*#B="x2Vis"*/ /*#b="x2Vis"*/x2/*#/b*/;
	//...code for main
}/*#/B*/ /*#/B*/

sub1() {
	int /*#B="s1Vis"*/ /*#b="s1Vis"*/s1/*#/b*/,/*#B="s2Vis"*/ /*#b="s2Vis"*/s2/*#/b*/;
	//...code for sub1
}/*#/B*/ /*#/B*/ /*#/B*/ /*#/B*/
int /*#B="locl1Vis"*/ /*#b="locl1Vis"*/locl1/*#/b*/,/*#B="locl2Vis"*/ /*#b="locl2Vis"*/locl2/*#/b*/;

sub2() {
	int /*#B="aVis"*/  /*#B="s21Vis"*/ /*#b="s21Vis"*/s21/*#/b*/, /*#B="s22Vis"*/ /*#b="s22Vis"*/s22/*#/b*/,/*#B="x12Vis"*/ /*#b="x12Vis"*/x1/*#/b*/;
	//...code for sub2
}/*#/B*/ /*#/B*/ /*#/B*/

sub3() {
/*#B="x1Vis"*/	int /*#B="s31Vis"*/ /*#b="s31Vis"*/s31/*#/b*/,/*#B="s32Vis"*/ /*#b="s32Vis"*/s32/*#/b*/;
	//...code for sub3
}/*#/B*/ /*#/B*/ /*#/B*/ /*#/B*/ /*#/B*/ /*#/B*/
