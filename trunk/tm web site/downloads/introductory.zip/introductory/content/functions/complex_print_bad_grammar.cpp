#include <iostream>
using namespace std;

void printComplex(double re, double im);

int main(){
	printComplex(3.2, "im part");
	return 0;
}
