	a[0]	// Element zero of the array
	a[i]	// Element i (the i'th element??)
	a[3]	// Element 3
	m[2][3]	// The element at row 2, column 3.
