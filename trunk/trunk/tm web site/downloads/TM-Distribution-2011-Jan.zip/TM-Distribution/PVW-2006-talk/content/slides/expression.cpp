#include <iostream>

using namespace std ;

int main() {
    int i = 9 ;
    int j = 8 ;
    float f = (i + j) / 2 ;
    cout << f << endl ;
    return 0 ;
}