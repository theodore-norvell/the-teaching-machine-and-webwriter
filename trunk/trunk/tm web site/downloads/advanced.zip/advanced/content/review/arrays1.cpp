int		a,c[10];
double	x[22],y[22][10];  /* y[row][col] */
