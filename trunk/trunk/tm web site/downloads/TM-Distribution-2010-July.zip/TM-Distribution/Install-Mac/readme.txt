First read the licence file: LICENCE

Do you agree with the terms?  Ok. Proceed.

To install the Teaching Machine, use "Finder" to move or copy the TeachingMachine.app application folder
in this folder to your Applications folder. (Finder will show the name as TeachinMachine and the
kind as "Application".)

The initial.tmcfg file will be in folder
  /Applications/TeachingMachine.app/Contents/Resources/Java/
Edit or replace this file to change your default configuration.

----------

Do you use Eclipse?  If so read the file Eclipse-plug-in-instructions.txt
to see how easy it is to install the TM as a plug-in for Eclipse.
