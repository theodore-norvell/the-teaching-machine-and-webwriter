void endStr(char*& beg) {
beg += strlen(beg);
}
