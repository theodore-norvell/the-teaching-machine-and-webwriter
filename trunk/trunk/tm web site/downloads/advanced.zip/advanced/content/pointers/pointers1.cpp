int a=2,b=3;
intSwap(a,b);
cout << a << ", " << b;
