#include <iostream>
#include <cmath>
using namespace std;


int main(){
    double x = sin(0);  // set x to sin(0)
    double y = cos(0);  // set y to cos(0)
    double sum;         // a sum variable
    sum = x + y;        // add x and y and set z to their sum
    return 0;           // tell OS everything ran fine
}
