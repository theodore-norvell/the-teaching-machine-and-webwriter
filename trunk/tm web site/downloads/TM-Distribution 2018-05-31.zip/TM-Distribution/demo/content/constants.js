// JavaScript Document

var siteTitle = "ITICSE2006 Demo";
var authors = "Michael Bruce-Lockhart & Theodore S. Norvell";
var generator = "DreamWeaver MX2004";
var bottomMark ="Interactive Embedded Examples: A Demonstration";
var copyright = "&copy; 2006 Michael Bruce-Lockhart & Theodore S. Norvell. All rights reserved.";
var courseNo = "ITICSE2006";

//  SITE IDENTIFICATION 
// Define either the organization and the course or the siteLogo and the siteTooltip
// If the siteLogo is defined (it should appear in the contentFolder) it will be used in
// the right hand of the webWriter navigation bar. The tooltip will be displayed when
// the mouse hovers over the logo. The logo should be no bigger than 120px wide by 50px high.
// If the logo is "", then the logo will be replaced by two lines of text. The top
// line will contain the organization string while the second will contain the course
// string
var organization = "Memorial University";
var course = "ITiCSE06 Demo";
var siteLogo = "";
var siteTooltip = "Interactive Embedded Examples: A Demonstration";

/****************************************************
 toolBar button control
 Turn to false if button should not be shown at all
 startWithShade only applies if startInLectureMode is true
*****************************************************/

var modeButton = true;
var shadeButton = true;
var showButton = true;
var printButton = true;
var helpButton = false;

var startInLectureMode = true;
var startWithShade = false;

/***********************************************************
	although these are in the form of variables they
	SHOULD NOT BE CHANGED BY AUTHORS as webWriter has
	to have some of these folders hard coded into it.
******************************************************/
var contentFolder = "content/"
var styleFolder = "style/";
var wwFolder = "webWriter/";
var imagesFolder = wwFolder + "images/";
var configurationsFolder = styleFolder + "configurations/";
/***********************************************************
    end of non-editable content
***********************************************************/

var videosFolder = contentFolder + "videos/";


