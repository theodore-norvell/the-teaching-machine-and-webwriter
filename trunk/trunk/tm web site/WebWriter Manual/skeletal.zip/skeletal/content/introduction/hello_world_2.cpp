/*#H*/ /******************************************************************
 * Memorial University of Newfoundland
 * Engineering 2420 Structured Programming
 *
 * hello_world_2.cpp -- variations on a theme.
 *
 * Author: Michael Bruce-Lockhart
 *   Date: 2006.05.01
 *
 *******************************************************************/
#include <iostream>
using namespace std;

/*#DA*/int main() {
    cout << "hello world!\n";
    cout << "hello world!" << endl;
    cout << "hello " << "world!" << endl;
    cout << "hello ";
	cout << "world!" << endl;
    return 0;
}/*#HA*/

