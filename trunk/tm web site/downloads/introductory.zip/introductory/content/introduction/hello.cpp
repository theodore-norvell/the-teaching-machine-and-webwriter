#include <iostream>
using namespace std;

void hello();

int main(){
    hello();
    cout << "world!";
    return 0;
}

void hello(){
     cout << "hello, ";
}
