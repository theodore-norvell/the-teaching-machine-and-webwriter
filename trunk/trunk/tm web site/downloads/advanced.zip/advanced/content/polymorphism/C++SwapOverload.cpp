void swap(int& a1,int& a2){
    int temp = a1;
    a1 = a2;
    a2 = temp;
}

void swap(char& a1,char& a2){
    char temp = a1;
    a1 = a2;
    a2 = temp;
}
