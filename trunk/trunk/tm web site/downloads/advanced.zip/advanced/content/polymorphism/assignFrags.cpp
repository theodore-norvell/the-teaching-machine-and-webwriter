/*#TA*/ Complex A(-3.1,4.2);
	Complex B(1.35,11.1);
	Complex D;
	D = A + B;
/*#/TA*/
/*#TB*/	Array A(10);
	Array B(10);
	Array D;
	
	load(A);	// input data to A
	load(B);	// input data to B
	D = A + B;
/*#/TB*/
