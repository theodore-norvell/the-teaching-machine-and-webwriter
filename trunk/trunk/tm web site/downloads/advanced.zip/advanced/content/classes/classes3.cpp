class WellStyled {
public:
	bool setData(int a, int b);
	double whatIsX();
private:
	int v1, v2;
	double x;
	bool why;
}
