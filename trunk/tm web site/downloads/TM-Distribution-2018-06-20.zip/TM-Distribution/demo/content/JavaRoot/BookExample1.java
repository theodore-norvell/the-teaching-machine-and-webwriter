

class BookExample1 {

    public static void main(String [] args){
        Book b = new Book( "Martin",
                           "Logic",
                           2000 ) ;
        Book c = b ;
        System.out.println("Done") ;
    }
}