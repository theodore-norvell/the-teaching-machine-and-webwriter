Complex x;

int main() {
	Complex y;
	// etc. ....
}

int f1(){
	Complex x,y;
	// ...
}

