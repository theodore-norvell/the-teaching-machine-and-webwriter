double function1(double, double);

int main(){
	double x=3., y= 17.5;
	double w;
	w = function1(x,y);
	// More code here
}

double function1(double a1, double a2){
	//code for function1
}
