// JavaScript Document
// Assumes tocNavigator.js loaded

var root = new Node("content/slides/titlePage.htm");

// Site Navigation map
// define the directories for convenience
var slides = "content/slides/";


var treeWalker = new Walker(root);

// Now define the navigation map
root.addChild(new Node(slides + "slide-010.htm"));
root.addChild(new Node(slides + "slide-020.htm"));
root.addChild(new Node(slides + "slide-021.htm"));
root.addChild(new Node(slides + "slide-022.htm"));
root.addChild(new Node(slides + "slide-030.htm"));
root.addChild(new Node(slides + "slide-031.htm"));
root.addChild(new Node(slides + "slide-032.htm"));
root.addChild(new Node(slides + "slide-040.htm"));
root.addChild(new Node(slides + "slide-041.htm"));
root.addChild(new Node(slides + "slide-042.htm"));
root.addChild(new Node(slides + "slide-043.htm"));
root.addChild(new Node(slides + "slide-045.htm"));
root.addChild(new Node(slides + "slide-046.htm"));
root.addChild(new Node(slides + "slide-047.htm"));
root.addChild(new Node(slides + "slide-048.htm"));
root.addChild(new Node(slides + "slide-049.htm"));
root.addChild(new Node(slides + "slide-050.htm"));
root.addChild(new Node(slides + "slide-070.htm"));
root.addChild(new Node(slides + "slide-080.htm"));